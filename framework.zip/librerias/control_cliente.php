<?php
//sleep(3);
include_once '../modelo/class_cliente.php';

$cliente = new class_cliente();
$type = $_GET['type'];
$term = $_GET['term'];

/**
 * Type 1: Resultados del autocomplete.
 * Type 2: Formulario para agregar usuarios.
 * Type 3: Funcion para agregar usuario.
 */
switch ($type) {
    case 1:     
        //echo $cliente->buscar($term);
        ?>
<script>alert('Estoy adentro');</script>
<?php 
    break;

    case 2:
?>
    <legend>Crear</legend>
        <form id="frmCrearCliente" class="form-horizontal" method="get" action="librerias/control_cliente.php">
            <div class="control-group">
              <label class="control-label" for="inputDocumento">Documento</label>
              <div class="controls">
                <input type="text" name="documento" id="documento" placeholder="Documento" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputNombre">Nombre</label>
              <div class="controls">
                <input type="text" name="nombre" id="nombre" placeholder="Nombre" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputApellidos">Apellidos</label>
              <div class="controls">
                <input type="text" name="apellido" id="apellido" placeholder="Apellidos" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label" for="inputEmpresa">Empresa</label>
              <div class="controls">
                <input type="text" name="empresa" id="empresa" placeholder="Empresa" required>
              </div>
            </div>
            <div class="control-group">
                <label class="control-label" for="inputCorreo">Correo</label>
                <div class="controls">
                <input type="email" name="correo" id="correo" placeholder="Correo" required>
                </div>
            </div>
            <div class="control-group">
                <label class="control-label" for="inputDireccion">Direccion</label>
                <div class="controls">
                <input type="text" name="direccion" id="direccion" placeholder="Direccion" required>
                </div>
            </div>
            <div class="control-group">
                <div class="controls">
                <div id="btnCancelarCliente" class="btn">Cancelar</div>
                <button id="btnCrearCliente" class="btn btn-warning" type="submit">Crear Cliente</button>
                </div>
            </div>
    </form>
<?php
    break;

    case 3:
        $cliente->crear($_GET);
    break;

    case 4:
        $cliente->actualizar($_GET, $_GET['id_usuario']);
    break;

    case 5:
        echo "he llegado aqui";
    break;

    default:
    break;
}

?>

    <script>
    $(document).ready(function(e){
           
    $('#frmCrearCliente').submit(function(e){

       var datos = $(this).serialize();
       
       //Llamado Ajax		
        $.ajax({
            type: "GET",
            url: "librerias/control_cliente.php",
            data: "type=3&"+datos,
            
           success: function(data){
                alert('Cliente ingresado');
		$('#resultados').fadeOut();			
            }//cierro success
	});//cierro ajax
       
       e.preventDefault(); 
        });
       });
       
       /**
    * Funcion al presionar el boton de cancelar la creacion de un cliente
    */
   $('#btnCancelarCliente').click(function(){
       $('#resultados').fadeOut();
       $('#resultados').html('');
       $('#busqCliente').fadeIn();
   });
    </script>