
	<div id="footer">
      <div class="container">
        <p class="muted credit">Todos los derechos reservados &copy; <?php echo date('Y');?><a href="http://construinversiones.com/"> ConstruInversiones</a>.</p>
      </div>
    </div>
    </div> <!-- /container -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-transition.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-alert.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-modal.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-dropdown.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-scrollspy.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-tab.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-tooltip.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-popover.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-button.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-collapse.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-carousel.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-typeahead.js"></script>
    <script src="<?php echo $raiz;?>librerias/js/formSesion.js"></script>
    <script src="<?php echo $raiz;?>librerias/js/funciones.js"></script>
    
    <script src="<?php echo $raiz;?>framework/bootstrap/js/wysihtml5-0.3.0.min.js"></script>
    <script src="<?php echo $raiz;?>framework/bootstrap/js/bootstrap-wysihtml5.js"></script>


    
  </body>
</html>
